package com.filecombination.CombineFiles;

import javax.xml.parsers.*;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import org.xml.sax.*;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.util.Collections;
import java.util.Comparator;

public class App{
	//arraylist that will hold all objects from the input files
	ArrayList<Record> recordList = new ArrayList<Record>();
	
	private void validateAndTransform(File fileIn) throws IOException, ParserConfigurationException, SAXException{
		String fileName = fileIn.getName();
        String fileExtension = fileName.substring(fileName.lastIndexOf("."));
        
        //check if file is of type .json
		if(fileExtension.equals(".json")){
			
			//parse json file
	        BufferedReader br = new BufferedReader(new FileReader(fileIn));
	        JsonParser parser = new JsonParser();
	        JsonArray array = parser.parse(br).getAsJsonArray();
	        for(int i=0; i < array.size(); i++) {
	        	
	        	JsonElement jsonElement = array.get(i);
	        	JsonObject jsonObject = jsonElement.getAsJsonObject();
	        	String packetsServiced = jsonObject.get("packets-serviced").toString();
	        	
	        	//if packets-serviced is not 0, create obj and add to array list
	        	//otherwise, skip row
	        	if(Integer.parseInt(packetsServiced) != 0) {

	        		Record currentRecord = new Record();
					currentRecord.setClientAddress(jsonObject.get("client-address").toString());
					currentRecord.setClientGuid(jsonObject.get("client-guid").toString());
					//convert epoch to formatted datetime string
					SimpleDateFormat sformat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss 'ADT'");
					Date convertedDate = new Date(Long.parseLong(jsonObject.get("request-time").toString()));
					String requestTime = sformat.format(convertedDate);
					
					currentRecord.setRequestTime(requestTime);
					currentRecord.setServiceGuid(jsonObject.get("service-guid").toString());
					currentRecord.setRetriesRequest(jsonObject.get("retries-request").toString());
					currentRecord.setPacketsRequested(jsonObject.get("packets-requested").toString());
					currentRecord.setPacketsServiced(jsonObject.get("packets-serviced").toString());
					currentRecord.setMaxHoleSize(jsonObject.get("max-hole-size").toString());
					
					recordList.add(currentRecord);
	
	        	}
	        }
	    
	    //Check if file is of type csv
		}else if(fileExtension.equals(".csv")){
			
			boolean headerRow = true;
			@SuppressWarnings("resource")
			BufferedReader csvReader = new BufferedReader(new FileReader(fileIn));
			String line = null;

			while ((line = csvReader.readLine()) != null) {
				if(headerRow) {
					headerRow=false;
				}else {
					//split csv at comma delimiter
					List<String> csvLineSplit = Arrays.asList(line.split(","));

					if(Integer.parseInt(csvLineSplit.get(6)) != 0) {						
						
						Record currentRecord = new Record();
						currentRecord.setClientAddress(csvLineSplit.get(0).trim().toString());
						currentRecord.setClientGuid(csvLineSplit.get(1).trim().toString());
						currentRecord.setRequestTime(csvLineSplit.get(2).trim().toString());
						currentRecord.setServiceGuid(csvLineSplit.get(3).trim().toString());
						currentRecord.setRetriesRequest(csvLineSplit.get(4).trim().toString());
						currentRecord.setPacketsRequested(csvLineSplit.get(5).trim().toString());
						currentRecord.setPacketsServiced(csvLineSplit.get(6).trim().toString());
						currentRecord.setMaxHoleSize(csvLineSplit.get(7).trim().toString());
						
						recordList.add(currentRecord);
					}
				}
			}
			
		//Check if file is of type xml
		}else if(fileExtension.equals(".xml")){					
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder = factory.newDocumentBuilder();
	        Document doc = builder.parse(fileIn);
	        NodeList reportList = doc.getElementsByTagName("report");
			for(int i=0; i<reportList.getLength(); i++) {
				Node r = reportList.item(i);
				Node report = (Node) r;
				NodeList childNodes = report.getChildNodes();
				if(Integer.parseInt(childNodes.item(1).getTextContent()) != 0) {	
					
					Record currentRecord = new Record();
					currentRecord.setClientAddress(childNodes.item(13).getTextContent().toString());
					currentRecord.setClientGuid(childNodes.item(3).getTextContent().toString());
					currentRecord.setRequestTime(childNodes.item(11).getTextContent().toString());
					currentRecord.setServiceGuid(childNodes.item(7).getTextContent().toString());
					currentRecord.setRetriesRequest(childNodes.item(9).getTextContent().toString());
					currentRecord.setPacketsRequested(childNodes.item(5).getTextContent().toString());
					currentRecord.setPacketsServiced(childNodes.item(1).getTextContent().toString());
					currentRecord.setMaxHoleSize(childNodes.item(15).getTextContent().toString());
					
					recordList.add(currentRecord);
				}
			}			
		}
	}
	
	//order the map in ascending order
	private void orderList(){
		Collections.sort(recordList, new Comparator<Record>(){
            public int compare(Record r1, Record r2) {
              return r1.getRequestTime().compareToIgnoreCase(r2.getRequestTime());
           }
       });
	}
	
	private void countOccurences() 
    { 
		//create arraylist with only the service-guids for more straight-forward iteration
		ArrayList<String> serviceGuids = new ArrayList<String>();
		for (int i=0; i < recordList.size(); i++) {
			serviceGuids.add(recordList.get(i).getServiceGuid().trim());
		}

		//hashmap to store all service-guids from above arraylist
        Map<String, Integer> serviceGuidMap = new HashMap<String, Integer>(); 
        for (String i : serviceGuids) { 
            Integer j = serviceGuidMap.get(i); 
            serviceGuidMap.put(i, (j == null) ? 1 : j + 1); 
        } 
  
        //print occurences of each unique service-guid
        for (Map.Entry<String, Integer> val : serviceGuidMap.entrySet()) { 
            System.out.println("service-guid " + val.getKey().replace("\"", "") + " " + "occurs " + val.getValue() + " times."); 
        } 
    } 
	
	//create new .csv file from map
	private void createCsv() throws IOException{
		//Create new csv file
		FileWriter csvWriter = new FileWriter("out/combined.csv");
		
		//Append header to csv file
		csvWriter.append("client-address");
		csvWriter.append(",");
		csvWriter.append("client-guid");
		csvWriter.append(",");
		csvWriter.append("request-time");
		csvWriter.append(",");
		csvWriter.append("service-guid");
		csvWriter.append(",");
		csvWriter.append("retries-request");
		csvWriter.append(",");
		csvWriter.append("packets-requested");
		csvWriter.append(",");
		csvWriter.append("packets-serviced");
		csvWriter.append(",");
		csvWriter.append("max-hole-size");
		csvWriter.append("\n");
					
		//iterate through list of objects & add to csv file
		for (int i=0; i < recordList.size(); i++) {
			csvWriter.append(recordList.get(i).getClientAddress());
			csvWriter.append(",");
			csvWriter.append(recordList.get(i).getClientGuid());
			csvWriter.append(",");
			csvWriter.append(recordList.get(i).getRequestTime());
			csvWriter.append(",");
			csvWriter.append(recordList.get(i).getServiceGuid());
			csvWriter.append(",");
			csvWriter.append(recordList.get(i).getRetriesRequest());
			csvWriter.append(",");
			csvWriter.append(recordList.get(i).getPacketsRequested());
			csvWriter.append(",");
			csvWriter.append(recordList.get(i).getPacketsServiced());
			csvWriter.append(",");
			csvWriter.append(recordList.get(i).getMaxHoleSize());
			csvWriter.append("\n");
		}

		//flush and close file
		csvWriter.flush();
		csvWriter.close();

	}
	
	public static void main(String[] args) throws IOException, ParserConfigurationException, SAXException{
		App combineData = new App();
        String inboundDataDir = System.getProperty("user.dir") + "\\in";
		File directory = new File(inboundDataDir);
		
		//validate and transform each file
		File[] dataFiles = directory.listFiles();
		if (dataFiles != null) {
			for (File file : dataFiles) {
				combineData.validateAndTransform(file);
			}
			//combine data in one csv file in out directory
			combineData.orderList();
			//sortData
			combineData.createCsv();
			//count occurences of service-guids
			combineData.countOccurences();
		}
	}
}
